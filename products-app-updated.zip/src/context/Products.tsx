import React from 'react';
import axios from 'axios';
// this is the equivalent to the createStore method of Redux
// https://redux.js.org/api/createstore


    const Products = React.createContext({
        products: [],
    });
export default Products;