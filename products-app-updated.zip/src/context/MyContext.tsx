import React from 'react';
import axios from 'axios';
// this is the equivalent to the createStore method of Redux
// https://redux.js.org/api/createstore


    const MyContext = React.createContext({
        users: [{firstname : 'test', lastname : 'test', email : 'test@gmail.com', password : 'test@123'}],
        addUser : (data:any) => {}
    });
export default MyContext;
