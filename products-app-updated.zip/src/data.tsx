export const PRODUCTS = [{item : 'laptop' , price : 200},
{item : 'mobile' , price: 120},
{item : 'shoe' , price: 70},
{item : 'camera' , price: 150},
{item : 'watch' , price: 100}]
export const TRANSACTIONS = [{email: 'jack@gmail.com', product: 'laptop', price : '200$', rewardPoints : 250},
{email: 'tom@gmail.com', product: 'mobile', price : '120$', rewardPoints : 90}]
