import React, { Component } from "react";
import { Container, Col, Row, CardGroup, Card, Button } from "react-bootstrap";
class Cart extends Component {

    render() {
        const items = JSON.parse(localStorage.getItem('cart') || '[]')
        return <Container>
            <Row><h2 style={{ margin: 'auto',  textDecoration : 'underline' }}>Order Details</h2></Row>
            <br></br>
            


            
               <Row >
                    <div>
                         <Col xs={12} md={12} lg={12} sm={12}></Col>
                        <Col  xs={12} md={12} lg={12} sm={12}>
                            {items.map((data: any, index: number) => (
                                <Card >
                                    <Card.Img style={{height : '15em', width : '15em'  ,  marginLeft: '26em'}} src={data.image} />
                                    <Card.Body>
                                        <Card.Title>{data.name}</Card.Title>
                                        <Card.Text>
                                           <strong>Order Code :</strong>  {data.code}<br></br>
                                           <strong>  Price :</strong> {data.price}<br></br>
                                           <strong> General Trivia : </strong>{data.desc}
                                        </Card.Text>
                                    </Card.Body>
                                    <Card.Footer>
                                        <small className="text-muted">Last Updated {index + 1} day/days ago.</small>
                                    </Card.Footer>
                                </Card>

                                ))}




                        </Col>
                        <Col xs={12} md={12} lg={12} sm={12}></Col>
                    </div>

</Row>
        </Container>
    }

}
export default Cart