import React, { Component } from "react";
import { Container, Col, Row, CardGroup, Card, Button, Form } from "react-bootstrap";
import axios from 'axios';
class Home extends Component {
    constructor(props: any) {
        super(props);
        this.state = {
            items: [], 
            actual : [],
        };
    }
   

    componentDidMount() {

            let datArr:any [] = [{"name":"Banana","price":"$.30","image":"https://www.meijer.com/content/dam/meijer/product/0000/00/0004/01/0000000004011_2_A1C1_1200.png","code":4011},{"name":"Strawberries","price":"$3.00","image":"https://www.meijer.com/content/dam/meijer/product/0780/35/3784/03/0780353784030_a1c1_1200.png","code":78035378403},{"name":"Clementine Mandarins","price":"$3.00","image":"https://www.meijer.com/content/dam/meijer/product/0033/38/3146/05/0033383146058_a1c1_1200.png","code":3338314605}]
            datArr.map((obj:any, index:number) =>  {
                if(index === 0) {
                    obj['desc'] = 'A banana is an elongated, edible fruit – botanically a berry – produced by several kinds of large herbaceous flowering plants in the genus Musa. In some countries, bananas used for cooking may be called "plantains", distinguishing them from dessert bananas'
                } else if(index === 1) {
                    obj['desc'] = 'The garden strawberry is a widely grown hybrid species of the genus Fragaria, collectively known as the strawberries, which are cultivated worldwide for their fruit. The fruit is widely appreciated for its characteristic aroma, bright red color, juicy texture, and sweetness'
                } else {
                    obj['desc'] = 'The garden strawberry is a widely grown hybrid species of the genus Fragaria, collectively known as the strawberries, which are cultivated worldwide for their fruit. The fruit is widely appreciated for its characteristic aroma, bright red color, juicy texture, and sweetness'
                }
            })
              
            this.setState({

                items: datArr,
                actual:datArr,
            });
      
    }
    addToCart = (data:any) => {
        localStorage.setItem('cart' , '[]');
        if(!localStorage.getItem('cart')){
            localStorage.setItem('cart' , JSON.stringify([data]));
          } else {
              localStorage.setItem('cart' , JSON.stringify([data]));
            }
            window.location.replace(window.location.origin+'/cart')
        }
    render() {
        const { items, actual }: any = this.state;
        return <Container>
             <Row><h2 style={{ margin: 'auto', textDecoration : 'underline'}}>Recent Orders</h2> 
             <Form.Group controlId="exampleForm.ControlInput1">
    <Form.Label></Form.Label>
    <Form.Control onChange={(e)=> {
        let objs = [...actual]
        objs =  objs.filter(val=>val['name'].toLowerCase().indexOf(e.target.value.toLowerCase())>=0)
       console.log(objs)
       this.setState({items : objs})
    }} type="text" placeholder="Filter Order By Name" />
  </Form.Group>
             </Row>
            <br></br>
            <Row className="justify-content-md-center">


               
                    <div>
                        
                        <Col md="auto" xs={12} lg={12} sm={12}>
                            <CardGroup>
                            {items.map((data: any, index: number) => (
                                <Card style={{cursor:'pointer',}} onClick={()=>this.addToCart(data)}>
                                    <Card.Img style={{height : '15em', width : '15em'}} variant="top" src={data.image} />
                                    <Card.Body>
                                        <Card.Title>{data.name}</Card.Title>
                                        <Card.Text>
                                            Order Code : {data.code}<br></br>
       Price : {data.price}
                                        </Card.Text>
                                    </Card.Body>
                                    <Card.Footer>
                                        <small className="text-muted">Last Updated {index + 1} day/days ago.</small>
                                        &nbsp;&nbsp;&nbsp;<Button variant="primary" onClick={()=>this.addToCart(data)}>View Order Details</Button>
                                    </Card.Footer>
                                </Card> 

                                ))}
                            </CardGroup>




                        </Col>
                       
                       
                    </div>
              

            </Row>
        </Container>
    }

}
export default Home