import React, { useState } from 'react';
import {ReactComponent as ReactLogo} from './logo.svg';
import './App.css';
import { Form, Button, Container, Row, Col, Dropdown, Table, Card, Accordion, Navbar, Nav } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import MyContext from './context/MyContext';
import {
  BrowserRouter,
  Switch,
  Route,
  Link,
  useHistory
} from 'react-router-dom';
import Home from './components/home';
import Cart from './components/details';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { AnyNaptrRecord } from 'dns';
const App: React.FC = () => {
  const [style, setStyle] = useState("menu")
  const [menuStatus, setMenuStatus] = useState("open")
  const navLinks = [
    { url: '/', name: 'View Orders' },
    { url: '/', name: 'Home' },
  ];
 
  const handleClick =()=> {
    
    switch(menuStatus)
    {
      case "open":
        
          setMenuStatus("close")
          setStyle("menu active")
        break;
      case "close":
          setMenuStatus("open")
          setStyle("menu")
        break;
    }   
      }

    
  return (
    
     <BrowserRouter>
    <div >
    
    <Navbar bg="primary" variant="dark">
    <Navbar.Brand>
    <i  onClick={handleClick} className="fa fa-align-justify" style={{fontSize:'33px' , cursor : 'pointer'}} ></i>
      <ReactLogo   style={{height: '65px'}}></ReactLogo>
      <i style={{fontSize : '25px', textDecoration : 'underline'}}>Orders App</i></Navbar.Brand>&nbsp;&nbsp;
    <Nav className="mr-auto">
    <Link to="/" style={{color : 'white'}}>Home / Orders</Link>&nbsp;&nbsp;
    
    {/* <Link to="/cart" style={{color : 'white'}}>Cart</Link>&nbsp;&nbsp; */}
    
    </Nav>
    <Nav>
      

    
  
    </Nav>
    </Navbar>
    <Container>
      <Row>
        <Col lg={2} style={{marginLeft: '-5em'}}>
        <div className={style}>               
          <ul>
            {navLinks.map(({ url, name }) => (
              <li>
                <a href={url} style={{cursor : 'pointer', color : 'white'}}>{name}</a>
              </li>
            ))}
          </ul>
        </div>
        </Col>
        <Col lg={10}  style={{marginLeft: '5em'}}>
        <Route exact path="/" component={Home}/>
         <Route path="/cart" component={Cart}/>
        
        </Col>
      </Row>
    
        
    </Container>
  
         
    </div>
     </BrowserRouter>
  );
}

export default App;
