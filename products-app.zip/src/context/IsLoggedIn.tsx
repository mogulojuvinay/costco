import React from 'react';
const isLoggedIn = React.createContext({
    login:false,
    }
    );
export default isLoggedIn;